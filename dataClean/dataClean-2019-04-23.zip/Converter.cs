﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace dataClean
{
    public class Converter
    {
        private string m_name;

        private string m_from;
        private bool m_isEncode;

        public Converter(string m_name)
        {
            this.m_name = m_name;
        }

        public Converter(string m_name,bool m_isEncode)
        {
            this.m_name = m_name;
            this.m_isEncode = m_isEncode;
        }

        public static List<Converter> Instance(string[] m_names)
        {
            List<Converter> list = new List<Converter>();
            foreach (string m_name in m_names)
            {
                list.Add(new Converter(m_name));
            }
            return list;
        }
        
        public string Name { get => m_name; set => m_name = value; }
        public string From { get => m_from; set => m_from = value; }
        public string To {

            get {

                if (m_isEncode)
                {
                    var codeNames = m_name.Split(new string[] {" ==> "," --> " },StringSplitOptions.None);
                    return EncodingConvert(m_from, Encoding.GetEncoding(codeNames[0]), Encoding.GetEncoding(codeNames[1]));
                }

                switch (m_name) {
              
                    case "html Entity":
                        return HttpUtility.HtmlDecode(m_from);
                    case "trim":
                        return m_from.Trim();
                    case "trimAll":
                        return m_from.Replace(" "/*普通空格*/, "").Replace("　"/*全角空格*/,"");
                    case "trimLeft":
                        return m_from.TrimStart();
                    case "trimRight":
                        return m_from.TrimEnd();                        
                }
                return m_from;
            }
        }

        public string GB2312ToUtf8(string gb2312String)
        {
            Encoding fromEncoding = Encoding.GetEncoding("gb2312");
            Encoding toEncoding = Encoding.UTF8;
            return EncodingConvert(gb2312String, fromEncoding, toEncoding);
        }

        public string GBKToUtf8(string gb2312String)
        {
            Encoding fromEncoding = Encoding.GetEncoding("GBK");
            Encoding toEncoding = Encoding.UTF8;
            return EncodingConvert(gb2312String, fromEncoding, toEncoding);
        }

        public string Utf8ToGB2312(string utf8String)
        {
            Encoding fromEncoding = Encoding.UTF8;
            Encoding toEncoding = Encoding.GetEncoding("gb2312");
            return EncodingConvert(utf8String, fromEncoding, toEncoding);
        }

        public string Utf8ToGBK(string utf8String)
        {
            Encoding fromEncoding = Encoding.UTF8;
            Encoding toEncoding = Encoding.GetEncoding("GBK");
            return EncodingConvert(utf8String, fromEncoding, toEncoding);
        }

        public string EncodingConvert(string fromString, Encoding fromEncoding, Encoding toEncoding)
        {
            byte[] fromBytes = fromEncoding.GetBytes(fromString);
            byte[] toBytes = Encoding.Convert(fromEncoding, toEncoding, fromBytes);

            string toString = toEncoding.GetString(toBytes);
            return toString;
        }

        public override string ToString()
        {
            return m_name;
        }
    }
}
